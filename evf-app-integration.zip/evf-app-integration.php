<?php
/**
 * Plugin Name: EVF App Integration
 * Description: Endpoint REST per l'app Eventi e Fiere Marketplace (preferiti + push token + notifiche + pannello admin).
 * Version: 1.2
 * Author: Eventi e Fiere
 */

// Blocca l'esecuzione se non siamo in WordPress
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Registra gli endpoint REST personalizzati.
 */
add_action( 'rest_api_init', function() {
    // Gestione dei preferiti (lista e aggiornamento)
    register_rest_route( 'evf/v1', '/favorites', array(
        array(
            'methods'  => 'GET',
            'callback' => 'evf_get_favorites',
            'permission_callback' => function() {
                return is_user_logged_in();
            },
        ),
        array(
            'methods'  => 'POST',
            'callback' => 'evf_update_favorites',
            'permission_callback' => function() {
                return is_user_logged_in();
            },
        ),
    ) );

    // Salvataggio del token push Expo
    register_rest_route( 'evf/v1', '/push-token', array(
        'methods'  => 'POST',
        'callback' => 'evf_save_push_token',
        'permission_callback' => function() {
            return is_user_logged_in();
        },
    ) );

    // Invio manuale di una notifica push (solo admin)
    register_rest_route( 'evf/v1', '/send-notification', array(
        'methods'  => 'POST',
        'callback' => 'evf_send_push_notification',
        'permission_callback' => function() {
            return current_user_can( 'manage_options' );
        },
    ) );
} );

/**
 * Restituisce l'elenco degli ID dei prodotti preferiti dell'utente corrente.
 *
 * @param WP_REST_Request $request
 * @return array
 */
function evf_get_favorites( WP_REST_Request $request ) {
    $user_id   = get_current_user_id();
    $favorites = get_user_meta( $user_id, 'evf_favorites', true );
    if ( empty( $favorites ) || ! is_array( $favorites ) ) {
        $favorites = array();
    }
    // Fornisce un array di interi consecutivi
    return array_values( array_map( 'intval', $favorites ) );
}

/**
 * Aggiunge o rimuove un prodotto dai preferiti dell'utente corrente.
 *
 * @param WP_REST_Request $request
 * @return array|WP_Error
 */
function evf_update_favorites( WP_REST_Request $request ) {
    $user_id   = get_current_user_id();
    $product_id = intval( $request->get_param( 'product_id' ) );
    $action    = sanitize_text_field( $request->get_param( 'action' ) );

    if ( ! $product_id || ! in_array( $action, array( 'add', 'remove' ), true ) ) {
        return new WP_Error( 'bad_request', 'Parametri non validi', array( 'status' => 400 ) );
    }

    $favorites = get_user_meta( $user_id, 'evf_favorites', true );
    if ( empty( $favorites ) || ! is_array( $favorites ) ) {
        $favorites = array();
    }

    if ( 'add' === $action && ! in_array( $product_id, $favorites, true ) ) {
        $favorites[] = $product_id;
    } elseif ( 'remove' === $action ) {
        $favorites = array_values( array_diff( $favorites, array( $product_id ) ) );
    }

    update_user_meta( $user_id, 'evf_favorites', $favorites );
    return array(
        'success'   => true,
        'favorites' => $favorites,
    );
}

/**
 * Salva o aggiorna il token Expo per l'utente corrente.
 *
 * @param WP_REST_Request $request
 * @return array|WP_Error
 */
function evf_save_push_token( WP_REST_Request $request ) {
    $user_id = get_current_user_id();
    $token   = sanitize_text_field( $request->get_param( 'token' ) );

    if ( $user_id && $token ) {
        update_user_meta( $user_id, 'expo_push_token', $token );
        return array(
            'success' => true,
            'token'   => $token,
        );
    }

    return new WP_Error( 'no_user', 'Utente non autenticato', array( 'status' => 401 ) );
}

/**
 * Invia una notifica push tramite il servizio Expo a tutti gli utenti con token registrato.
 *
 * @param WP_REST_Request $request
 * @return array|WP_Error
 */
function evf_send_push_notification( WP_REST_Request $request ) {
    $title = sanitize_text_field( $request->get_param( 'title' ) );
    $body  = sanitize_text_field( $request->get_param( 'body' ) );

    if ( ! $title && ! $body ) {
        return new WP_Error( 'bad_request', 'Titolo o testo mancante', array( 'status' => 400 ) );
    }

    // Recupera gli utenti che hanno un token Expo salvato
    $users = get_users( array(
        'meta_key'     => 'expo_push_token',
        'meta_compare' => 'EXISTS',
    ) );

    if ( empty( $users ) ) {
        return array(
            'success' => false,
            'message' => 'Nessun token registrato',
        );
    }

    $messages = array();
    foreach ( $users as $user ) {
        $token = get_user_meta( $user->ID, 'expo_push_token', true );
        if ( $token ) {
            $messages[] = array(
                'to'    => $token,
                'sound' => 'default',
                'title' => $title,
                'body'  => $body,
            );
        }
    }

    // Effettua la chiamata al servizio Expo per inviare le notifiche
    $response = wp_remote_post( 'https://exp.host/--/api/v2/push/send', array(
        'headers' => array(
            'Content-Type' => 'application/json',
        ),
        'body'    => wp_json_encode( $messages ),
        'timeout' => 20,
    ) );

    if ( is_wp_error( $response ) ) {
        return array(
            'success' => false,
            'error'   => $response->get_error_message(),
        );
    }

    return array(
        'success' => true,
        'sent'    => count( $messages ),
    );
}

/**
 * Aggiunge una voce di menu nella dashboard per l'invio manuale delle notifiche push.
 */
add_action( 'admin_menu', function() {
    add_menu_page(
        'Notifiche Push',
        'Notifiche Push',
        'manage_options',
        'evf-push',
        'evf_push_admin_page',
        'dashicons-megaphone',
        60
    );
} );

/**
 * Callback per la pagina di amministrazione delle notifiche push.
 */
function evf_push_admin_page() {
    ?>
    <div class="wrap">
        <h1>Invia Notifica Push</h1>
        <form method="post">
            <?php wp_nonce_field( 'evf_push_action', 'evf_push_nonce' ); ?>
            <table class="form-table">
                <tr>
                    <th><label for="evf_push_title">Titolo</label></th>
                    <td><input name="evf_push_title" type="text" id="evf_push_title" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="evf_push_body">Testo</label></th>
                    <td><textarea name="evf_push_body" id="evf_push_body" class="large-text" rows="4"></textarea></td>
                </tr>
            </table>
            <?php submit_button( 'Invia Notifica' ); ?>
        </form>
    </div>
    <?php
    if ( isset( $_POST['evf_push_title'], $_POST['evf_push_body'], $_POST['evf_push_nonce'] )
        && wp_verify_nonce( $_POST['evf_push_nonce'], 'evf_push_action' ) ) {
        $request = new WP_REST_Request( 'POST', '/evf/v1/send-notification' );
        $request->set_param( 'title', sanitize_text_field( $_POST['evf_push_title'] ) );
        $request->set_param( 'body', sanitize_text_field( $_POST['evf_push_body'] ) );
        $response = rest_do_request( $request );
        if ( $response->is_error() ) {
            echo '<div class="error"><p>Errore invio: ' . esc_html( $response->as_error()->get_error_message() ) . '</p></div>';
        } else {
            $data = $response->get_data();
            echo '<div class="updated"><p>Notifica inviata a ' . intval( $data['sent'] ) . ' utenti.</p></div>';
        }
    }
}
