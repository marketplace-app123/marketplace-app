import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";
import client from "../api/client";

const useAuthStore = create((set) => ({
  user: null,
  token: null,
  login: async (username, password) => {
    const res = await client.post("/jwt-auth/v1/token", { username, password });
    const { token, user_nicename, user_email } = res.data;
    await AsyncStorage.setItem("token", token);
    set({ token, user: { name: user_nicename, email: user_email } });
  },
  logout: async () => {
    await AsyncStorage.removeItem("token");
    set({ user: null, token: null });
  },
}));

export default useAuthStore;