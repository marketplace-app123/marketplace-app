import React, { useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import useAuthStore from "../store/useAuthStore";

export default function LoginScreen({ navigation }) {
  const { login } = useAuthStore();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      await login(username, password);
      navigation.replace("Main");
    } catch (err) {
      alert("Errore login. Verifica JWT su WordPress e credenziali.");
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", padding: 20 }}>
      <Text style={{ fontSize: 22, marginBottom: 12 }}>Accedi</Text>
      <TextInput
        style={{ borderWidth: 1, marginBottom: 10, padding: 8 }}
        placeholder="Email o username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={{ borderWidth: 1, marginBottom: 20, padding: 8 }}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Entra" onPress={handleLogin} />
    </View>
  );
}