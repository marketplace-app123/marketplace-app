import React from "react";
import { View, Text } from "react-native";

export default function ChatScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Chat (collega Better Messages API o Firebase)</Text>
    </View>
  );
}