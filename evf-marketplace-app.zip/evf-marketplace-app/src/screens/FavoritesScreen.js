import React, { useEffect, useState } from "react";
import { View, Text, FlatList, ActivityIndicator, TouchableOpacity } from "react-native";
import client from "../api/client";

export default function FavoritesScreen() {
  const [favoritesIds, setFavoritesIds] = useState(null);
  const [products, setProducts] = useState([]);

  // Carica gli ID dei preferiti
  const loadFavorites = () => {
    client
      .get("/evf/v1/favorites")
      .then((res) => setFavoritesIds(res.data || []))
      .catch(() => alert("Errore lettura preferiti (JWT richiesto)"));
  };

  useEffect(loadFavorites, []);

  // Carica i prodotti per gli ID dei preferiti
  useEffect(() => {
    if (favoritesIds === null) return;
    if (favoritesIds.length === 0) {
      setProducts([]);
      return;
    }
    Promise.all(
      favoritesIds.map((id) => client.get(`/wc/v3/products/${id}`))
    )
      .then((resArray) => setProducts(resArray.map((r) => r.data)))
      .catch(() => alert("Errore caricamento prodotti preferiti"));
  }, [favoritesIds]);

  const removeFavorite = async (productId) => {
    try {
      await client.post("/evf/v1/favorites", { product_id: productId, action: "remove" });
      loadFavorites();
    } catch {
      alert("Errore rimozione preferito");
    }
  };

  if (favoritesIds === null)
    return (
      <View style={{ flex: 1, justifyContent: "center" }}>
        <ActivityIndicator />
      </View>
    );

  return (
    <View style={{ flex: 1, padding: 10 }}>
      <Text style={{ fontSize: 20, marginBottom: 8 }}>Preferiti</Text>
      <FlatList
        data={products}
        ListEmptyComponent={<Text>Nessun preferito</Text>}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ padding: 12, borderBottomWidth: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: "bold" }}>{item.name}</Text>
            <Text>{item.price} €</Text>
            <TouchableOpacity onPress={() => removeFavorite(item.id)} style={{ marginTop: 6 }}>
              <Text style={{ color: "red" }}>🗑️ Rimuovi dai preferiti</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}