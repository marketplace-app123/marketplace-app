import React, { useEffect, useState } from "react";
import { View, Text, FlatList, ActivityIndicator, TouchableOpacity } from "react-native";
import client from "../api/client";

export default function ProductsScreen({ route }) {
  const { category, title } = route.params || {};
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const url = category
      ? `/wc/v3/products?category=${category}&per_page=20`
      : "/wc/v3/products?per_page=20";
    client
      .get(url)
      .then((res) => setProducts(res.data))
      .catch(() => alert("Errore caricamento prodotti"))
      .finally(() => setLoading(false));
  }, [category]);

  const addToFavorites = async (productId) => {
    try {
      await client.post("/evf/v1/favorites", { product_id: productId, action: "add" });
      alert("Aggiunto ai preferiti");
    } catch {
      alert("Errore salvataggio preferito (richiede login JWT)");
    }
  };

  if (loading)
    return (
      <View style={{ flex: 1, justifyContent: "center" }}>
        <ActivityIndicator />
      </View>
    );

  return (
    <View style={{ flex: 1, padding: 10 }}>
      {title ? <Text style={{ fontSize: 20, marginBottom: 8 }}>{title}</Text> : null}
      <FlatList
        data={products}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ padding: 12, borderBottomWidth: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: "bold" }}>{item.name}</Text>
            <Text>{item.price} €</Text>
            <TouchableOpacity onPress={() => addToFavorites(item.id)} style={{ marginTop: 6 }}>
              <Text style={{ color: "blue" }}>⭐ Aggiungi ai preferiti</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}