import React from "react";
import { View, Text, Button } from "react-native";
import useAuthStore from "../store/useAuthStore";

export default function ProfileScreen({ navigation }) {
  const { user, logout } = useAuthStore();

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      {user ? (
        <>
          <Text style={{ fontSize: 18 }}>{user.name}</Text>
          <Text style={{ marginBottom: 16 }}>{user.email}</Text>
          <Button
            title="Logout"
            onPress={() => {
              logout();
              navigation.replace("Login");
            }}
          />
        </>
      ) : (
        <Text>Non sei loggato</Text>
      )}
    </View>
  );
}